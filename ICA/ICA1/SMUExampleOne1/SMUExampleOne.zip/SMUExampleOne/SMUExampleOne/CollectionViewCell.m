//
//  CollectionViewCell.m
//  SMUExampleOne
//
//  Created by Eric Larson on 1/21/15.
//  Copyright (c) 2015 Eric Larson. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

@end
